import os
import cv2
import torch
import torch.nn as nn
from torchvision import transforms
from PIL import Image
from collections import Counter, deque
import random
import time
import threading
import json
import urllib.request
from flask import Flask, request, jsonify, render_template, Response
import pygame

# 1. KHỞI TẠO ÂM THANH CHUẨN CHO RASPBERRY PI (CARD 2 HEADPHONES)
os.environ['SDL_AUDIODRIVER'] = 'alsa'
os.environ['AUDIODEV'] = 'hw:2,0'
pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=4096)

# Khởi tạo Flask App
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, 
            template_folder=os.path.join(BASE_DIR, 'templates'), 
            static_folder=os.path.join(BASE_DIR, 'web'))

# Biến toàn cục quản lý trạng thái hệ thống
is_triggered = False
is_scanning = False
is_paused = False

latest_status = {
    "emotion": "Bình thường",
    "song": "Chưa có nhạc phát",
    "led_trigger": False,
    "led_state": False,        # Trạng thái LED (Chỉ True khi AI nhận diện xong cảm xúc)
    "song_start_time": 0,
    "song_duration": 0,
    "weather": {
        "temp": 30,
        "desc": "Đang cập nhật...",
        "humidity": 75,
        "wind": 10
    }
}

# ==========================================
# 0. LUỒNG CẬP NHẬT THỜI TIẾT THỜI GIAN THỰC
# ==========================================
def update_weather_realtime():
    """Tự động cập nhật thông tin thời tiết TP.HCM theo thời gian thực"""
    global latest_status
    while True:
        try:
            url = "https://wttr.in/Ho_Chi_Minh?format=j1"
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=8) as response:
                data = json.loads(response.read().decode())
                current = data['current_condition'][0]
                
                desc = current['weatherDesc'][0]['value']
                if 'lang_vi' in current and current['lang_vi'] and len(current['lang_vi']) > 0:
                    desc = current['lang_vi'][0]['value']

                latest_status["weather"] = {
                    "temp": int(current['temp_C']),
                    "desc": desc,
                    "humidity": int(current['humidity']),
                    "wind": int(current['windspeedKmph'])
                }
        except Exception as e:
            print("[WEATHER REALTIME] Lỗi lấy dữ liệu thời tiết:", e)
        
        time.sleep(600)

weather_thread = threading.Thread(target=update_weather_realtime, daemon=True)
weather_thread.start()

# ==========================================
# 1. KIẾN TRÚC MẠNG CNN 4 BLOCK
# ==========================================
class EmotionCNN(nn.Module):
    def __init__(self):
        super(EmotionCNN, self).__init__()
        self.features = nn.Sequential(
            nn.Conv2d(1, 32, kernel_size=3, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.Conv2d(32, 32, kernel_size=3, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.MaxPool2d(2, 2),
            nn.Dropout(0.25),

            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.Conv2d(64, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.MaxPool2d(2, 2),
            nn.Dropout(0.25),

            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.Conv2d(128, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.MaxPool2d(2, 2),
            nn.Dropout(0.25),

            nn.Conv2d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(),
            nn.MaxPool2d(2, 2),
            nn.Dropout(0.25)
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(256 * 3 * 3, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(256, 7)
        )

    def forward(self, x):
        x = self.features(x)
        x = self.classifier(x)
        return x

# ==========================================
# 2. KHỞI TẠO MÔ HÌNH VÀ HỆ THỐNG
# ==========================================
MODEL_PATH = os.path.join(BASE_DIR, 'emotion_model.pth')
CASCADE_PATH = os.path.join(BASE_DIR, 'haarcascade_frontalface_default.xml')
MUSIC_DIR = os.path.join(BASE_DIR, 'music')

device = torch.device("cpu")
model = EmotionCNN().to(device)

try:
    state_dict = torch.load(MODEL_PATH, map_location=device)
    model.load_state_dict(state_dict)
    print("-> Nạp thành công weights emotion_model.pth!")
except Exception as e:
    print("Lỗi nạp weights:", e)
    exit()

model.eval()

EMOTIONS = ["Tuc gian", "Ghe tom", "So hai", "Vui ve", "Buon", "Bat ngo", "Binh thuong"]
EMOTION_TO_FOLDER = {
    "Tuc gian": "angry",
    "Ghe tom": "disgust",
    "So hai": "fear",
    "Vui ve": "happy",
    "Buon": "sad",
    "Bat ngo": "surprise",
    "Binh thuong": "neutral"
}

face_cascade = cv2.CascadeClassifier(CASCADE_PATH)

transform = transforms.Compose([
    transforms.ToPILImage(),
    transforms.Grayscale(num_output_channels=1),
    transforms.Resize((48, 48)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.5], std=[0.5])
])

# ==========================================
# 3. HÀM PHÁT NHẠC THEO CẢM XÚC
# ==========================================
def play_music_for_emotion(emotion_label):
    global latest_status, is_paused
    folder_name = EMOTION_TO_FOLDER.get(emotion_label, "neutral")
    emotion_folder = os.path.join(MUSIC_DIR, folder_name)
    
    if not os.path.exists(emotion_folder):
        emotion_folder = os.path.join(MUSIC_DIR, emotion_label)

    if os.path.exists(emotion_folder):
        songs = [f for f in os.listdir(emotion_folder) if f.endswith(('.mp3', '.wav'))]
        if songs:
            song_name = random.choice(songs)
            selected_song = os.path.join(emotion_folder, song_name)
            print(f"[MUSIC] Đang phát nhạc: {selected_song}")
            
            duration = 180
            try:
                sound = pygame.mixer.Sound(selected_song)
                duration = int(sound.get_length())
            except Exception as e:
                print("Lỗi đọc duration file nhạc:", e)

            pygame.mixer.music.load(selected_song)
            pygame.mixer.music.play()
            is_paused = False

            latest_status["emotion"] = emotion_label
            latest_status["song"] = song_name
            latest_status["song_start_time"] = time.time()
            latest_status["song_duration"] = duration
            return
            
    print(f"[MUSIC] Không tìm thấy file nhạc trong thư mục: {emotion_folder}")
    latest_status["emotion"] = emotion_label
    latest_status["song"] = "Chưa có file nhạc"
    latest_status["song_duration"] = 0

# ==========================================
# 4. FLASK ROUTES & API ĐỒNG BỘ HTML / ESP32
# ==========================================
output_frame = None
lock = threading.Lock()

@app.route('/')
def index():
    return render_template('index.html')

# Trigger từ PIR (Không bật LED ở giai đoạn này)
@app.route('/trigger', methods=['POST'])
def trigger():
    global is_triggered, latest_status, is_scanning, is_paused
    
    music_playing = pygame.mixer.music.get_busy()
    is_actively_playing = music_playing and not is_paused
    
    if is_actively_playing or is_scanning:
        print("[ESP32] Bỏ qua trigger vì hệ thống đang bận.")
        return jsonify({"status": "busy", "message": "System is busy"}), 200

    data = request.get_json()
    if data and data.get('motion'):
        print("\n[ESP32] ===> PHÁT HIỆN NGƯỜI LẠI GẦN! Kích hoạt quét AI (Đèn LED chưa bật) <===")
        is_triggered = True
        latest_status["led_trigger"] = False
        latest_status["led_state"] = False  # Đảm bảo giữ LED TẮT khi mới có chuyển động
        return jsonify({"status": "success"}), 200
        
    return jsonify({"status": "failed"}), 400

# API RESET TOÀN HỆ THỐNG KHI BẤM NÚT VẬT LÝ ESP32
@app.route('/api/reset', methods=['POST'])
def reset_system():
    global is_triggered, is_scanning, is_paused, latest_status
    
    pygame.mixer.music.stop()
    is_paused = False
    
    latest_status["emotion"] = "Đang quét khuôn mặt..."
    latest_status["song"] = "Đang chọn bài hát..."
    latest_status["led_trigger"] = False
    latest_status["led_state"] = False     # Ép TẮT LED khi Reset
    latest_status["song_start_time"] = 0
    latest_status["song_duration"] = 0
    
    is_triggered = True
    is_scanning = True
    
    print("\n[RESET] ===> Nhận lệnh RESET từ Nút ESP32! Dừng nhạc, TẮT LED & Bắt đầu quét lượt mới <===")
    return jsonify({"status": "success", "message": "System reset and LED turned off"}), 200

# API cho ESP32 kiểm tra cờ Bật LED và Trạng thái phát nhạc
@app.route('/api/check_led', methods=['GET'])
def check_led():
    global latest_status, is_paused
    music_playing = pygame.mixer.music.get_busy()
    is_actively_playing = music_playing and not is_paused

    # Tự động TẮT LED khi phát hết nhạc
    if not is_actively_playing and latest_status.get("song_start_time", 0) > 0:
        latest_status["led_state"] = False
        latest_status["led_trigger"] = False
        latest_status["song_start_time"] = 0

    return jsonify({
        "turn_on_led": latest_status.get("led_trigger", False),
        "led_state": latest_status.get("led_state", False),
        "emotion": latest_status.get("emotion", "waiting"),
        "music_playing": is_actively_playing
    })

# API trả dữ liệu trạng thái cho Web UI
@app.route('/status', methods=['GET'])
@app.route('/api/status', methods=['GET'])
def get_status():
    global is_paused
    music_playing = pygame.mixer.music.get_busy()
    is_actively_playing = music_playing and not is_paused

    if not is_actively_playing and latest_status.get("song_start_time", 0) > 0:
        latest_status["led_state"] = False
        latest_status["led_trigger"] = False
        latest_status["song_start_time"] = 0

    current_emotion = latest_status.get("emotion", "Bình thường")
    has_person = 1 if (is_scanning or current_emotion not in ["Đang chờ người dùng...", "Bình thường"]) else 0

    music_state = "paused" if is_paused else ("playing" if music_playing else "stopped")

    current_pos = 0
    if is_actively_playing:
        current_pos = int(time.time() - latest_status.get("song_start_time", time.time()))
        if current_pos > latest_status.get("song_duration", 0):
            current_pos = latest_status.get("song_duration", 0)

    return jsonify({
        "faces_count": has_person,
        "emotion": current_emotion,
        "song": latest_status.get("song", "Chưa có nhạc phát"),
        "music_state": music_state,
        "song_pos": current_pos,
        "song_dur": latest_status.get("song_duration", 0),
        "led_state": latest_status.get("led_state", False),
        "weather": latest_status.get("weather")
    })

# API điều khiển nhạc từ Web UI
@app.route('/api/music/<action>', methods=['POST'])
def music_control(action):
    global is_paused, latest_status
    if action == 'toggle':
        if pygame.mixer.music.get_busy():
            if is_paused:
                pygame.mixer.music.unpause()
                is_paused = False
            else:
                pygame.mixer.music.pause()
                is_paused = True
    elif action == 'stop':
        pygame.mixer.music.stop()
        is_paused = False
        latest_status["song"] = "Đã kết thúc bài hát"
        latest_status["led_state"] = False
        latest_status["led_trigger"] = False
        latest_status["song_start_time"] = 0
        print("[MUSIC] Đã kết thúc bài hát & Tắt LED.")

    return jsonify({
        "title": latest_status.get("song", "AI Music Player"),
        "artist": f"Cảm xúc: {latest_status.get('emotion', 'Bình thường')}"
    })

# API điều khiển đèn LED từ Web UI
@app.route('/api/led', methods=['POST'])
def led_control():
    global latest_status
    data = request.get_json()
    state = data.get('state', False) if data else False
    latest_status["led_state"] = state
    if not state:
        latest_status["led_trigger"] = False
        latest_status["song_start_time"] = 0
    print(f"[LED] Web UI chuyển trạng thái đèn: {'BẬT' if state else 'TẮT'}")
    return jsonify({"status": "success", "led_state": state})

def generate_frames():
    global output_frame, lock
    while True:
        with lock:
            if output_frame is None:
                time.sleep(0.01)
                continue
            ret, encoded_image = cv2.imencode('.jpg', output_frame)
            if not ret:
                time.sleep(0.01)
                continue
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + bytearray(encoded_image) + b'\r\n')
        time.sleep(0.03)

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

def start_flask():
    app.run(host='0.0.0.0', port=5000, debug=False, use_reloader=False)

# ==========================================
# 5. LUỒNG CHÍNH: CAMERA & QUÉT AI
# ==========================================
if __name__ == '__main__':
    flask_thread = threading.Thread(target=start_flask, daemon=True)
    flask_thread.start()

    print("\n--- SERVER SMART MIRROR AI SẴN SÀNG ---")
    cap = cv2.VideoCapture(0)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    if not cap.isOpened():
        print("[ERROR] Không thể mở Camera!")
        exit()

    emotion_history = deque(maxlen=5)
    detecting_start_time = 0
    is_scanning = False

    while True:
        ret, frame = cap.read()
        if not ret or frame is None:
            time.sleep(0.01)
            continue

        if is_triggered:
            is_triggered = False
            is_scanning = True
            detecting_start_time = time.time()
            emotion_history.clear()
            latest_status["emotion"] = "Đang quét khuôn mặt..."
            latest_status["song"] = "Đang chọn bài hát..."
            latest_status["led_trigger"] = False
            latest_status["led_state"] = False  # LED Giữ TẮT trong suốt lúc quét
            print("[AI] Bắt đầu quét khuôn mặt trong 4 giây (Đèn LED chưa bật)...")

        if is_scanning:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

            current_emotion = ""
            for (x, y, w, h) in faces:
                face_roi = gray[y:y+h, x:x+w]
                input_tensor = transform(face_roi).unsqueeze(0).to(device)

                with torch.no_grad():
                    output = model(input_tensor)
                    pred_idx = torch.argmax(output, dim=1).item()
                    raw_label = EMOTIONS[pred_idx]
                    emotion_history.append(raw_label)
                    current_emotion = raw_label

                cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
                cv2.putText(frame, current_emotion, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)

            # ĐỦ 4 GIÂY QUÉT AI
            if time.time() - detecting_start_time >= 4.0:
                is_scanning = False
                if len(emotion_history) > 0:
                    final_label = Counter(emotion_history).most_common(1)[0][0]
                    print(f"[AI] PHÁT HIỆN THÀNH CÔNG CẢM XÚC: {final_label} -> KÍCH HOẠT BẬT LED VÀ PHÁT NHẠC!")
                    play_music_for_emotion(final_label)
                    
                    # CHỈ BẬT LED TẠI ĐÂY KHI NHẬN DIỆN THÀNH CÔNG CẢM XÚC
                    latest_status["led_trigger"] = True
                    latest_status["led_state"] = True
                else:
                    print("[AI] Không tìm thấy khuôn mặt nào.")
                    latest_status["emotion"] = "Bình thường"
                    latest_status["led_state"] = False
                    latest_status["led_trigger"] = False

        with lock:
            output_frame = frame.copy()

        time.sleep(0.01)

    cap.release()
