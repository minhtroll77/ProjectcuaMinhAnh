#include <WiFi.h>
#include <HTTPClient.h>
#include <Adafruit_NeoPixel.h>

// ==========================================================
// 1. CẤU HÌNH WI-FI VÀ SERVER RASPBERRY PI
// ==========================================================
const char* ssid     = "Hoang";
const char* password = "02040204";

const char* triggerUrl  = "http://172.20.10.3:5000/trigger";
const char* checkLedUrl = "http://172.20.10.3:5000/api/check_led";
const char* resetUrl    = "http://172.20.10.3:5000/api/reset";

// ==========================================================
// 2. CẤU HÌNH CHÂN PHẦN CỨNG ESP32
// ==========================================================
const int PIR_PIN       = 13; // Chân OUT cảm biến PIR
const int LED_PIN       = 17; // Chân DI dải LED WS2812B (GPIO 17)
const int RESET_BTN_PIN = 16; // Chân Nút bấm Reset (GPIO 16)
const int NUM_LEDS      = 60; // Số lượng bóng LED trên dây WS2812B

Adafruit_NeoPixel strip(NUM_LEDS, LED_PIN, NEO_GRB + NEO_KHZ800);

bool currentPhysicalLedState = false;

void turnOnAllLeds() {
  if (!currentPhysicalLedState) {
    for (int i = 0; i < NUM_LEDS; i++) {
      strip.setPixelColor(i, strip.Color(255, 255, 255));
    }
    strip.show();
    currentPhysicalLedState = true;
  }
}

void forceTurnOffAllLeds() {
  strip.clear();
  strip.show();
  currentPhysicalLedState = false;
}

bool isButtonPressed() {
  return (digitalRead(RESET_BTN_PIN) == LOW);
}

void setup() {
  Serial.begin(115200);
  
  pinMode(PIR_PIN, INPUT);
  pinMode(RESET_BTN_PIN, INPUT_PULLUP);
  
  strip.begin();
  strip.setBrightness(200);
  forceTurnOffAllLeds();

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\n[SYSTEM] Đã kết nối Wi-Fi thành công!");
  Serial.print("[SYSTEM] IP ESP32: ");
  Serial.println(WiFi.localIP());
}

// Gửi tín hiệu Reset về Raspberry Pi
bool sendResetSignal() {
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    http.begin(resetUrl);
    http.addHeader("Content-Type", "application/json");
    
    int httpResponseCode = http.POST("{}");
    http.end();
    if (httpResponseCode == 200) {
      Serial.println("[BTN] Đã gửi lệnh RESET về Server thành công!");
      return true;
    }
  }
  return false;
}

// Gửi tín hiệu kích hoạt quét qua PIR
bool triggerRaspberryPi() {
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    http.begin(triggerUrl);
    http.addHeader("Content-Type", "application/json");
    
    int httpResponseCode = http.POST("{\"motion\": true}");
    if (httpResponseCode == 200) {
      String response = http.getString();
      http.end();
      if (response.indexOf("busy") != -1) {
        return false;
      }
      return true;
    }
    http.end();
  }
  return false;
}

// Lấy trạng thái đồng bộ LED & Nhạc từ Server
bool getLedAndMusicStatus(bool &ledStateOut, bool &musicPlayingOut) {
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    http.begin(checkLedUrl);
    http.setTimeout(2000);
    
    int httpResponseCode = http.GET();
    if (httpResponseCode == 200) {
      String payload = http.getString();
      http.end();

      if (payload.indexOf("\"led_state\":true") != -1 || payload.indexOf("\"led_state\": true") != -1) {
        ledStateOut = true;
      } else {
        ledStateOut = false;
      }

      if (payload.indexOf("\"music_playing\":true") != -1 || payload.indexOf("\"music_playing\": true") != -1) {
        musicPlayingOut = true;
      } else {
        musicPlayingOut = false;
      }
      return true;
    }
    http.end();
  }
  return false;
}

// Vòng lặp chờ phát xong nhạc + Đồng bộ nút bấm LED Web UI
void waitForSongToFinish() {
  Serial.println("-> Nhạc đang phát... ESP32 chờ nhạc dừng hoặc bấm Nút Reset.");
  while (true) {
    if (isButtonPressed()) {
      delay(50);
      if (isButtonPressed()) {
        Serial.println("\n[BTN] Bấm Nút Reset trong lúc phát nhạc -> TẮT LED & Dừng nhạc!");
        forceTurnOffAllLeds();
        sendResetSignal();
        break; 
      }
    }

    bool serverLedState = false;
    bool isMusicPlaying = false;
    if (getLedAndMusicStatus(serverLedState, isMusicPlaying)) {
      if (serverLedState) {
        turnOnAllLeds();
      } else {
        forceTurnOffAllLeds();
      }

      if (!isMusicPlaying) {
        Serial.println("-> Bài hát đã dừng!");
        break;
      }
    }
    delay(300);
  }
  
  forceTurnOffAllLeds();
}

// Quá trình chờ AI quét mặt và Bật LED
void runScanProcess() {
  Serial.println("-> Chờ Raspberry Pi quét khuôn mặt (Đèn LED đang TẮT)...");
  forceTurnOffAllLeds(); // Đảm bảo LED tắt trong thời gian đang quét AI
  
  unsigned long startTime = millis();
  bool emotionDetected = false;
  
  while (millis() - startTime < 8000) {
    if (isButtonPressed()) {
      forceTurnOffAllLeds();
      sendResetSignal();
      return; 
    }

    bool serverLedState = false;
    bool isMusicPlaying = false;
    // Đèn chỉ được bật khi Server trả về serverLedState == true (tức là sau khi đã nhận diện xong cảm xúc)
    if (getLedAndMusicStatus(serverLedState, isMusicPlaying) && serverLedState) {
      emotionDetected = true;
      break;
    }
    delay(300);
  }

  if (emotionDetected) {
    Serial.println("-> ĐÃ PHÁT HIỆN CẢM XÚC! BẬT DẢI LED WS2812B.");
    turnOnAllLeds();
    
    delay(1000); 
    waitForSongToFinish(); 

    forceTurnOffAllLeds();
  } else {
    Serial.println("-> Hết thời gian / Không nhận diện được cảm xúc. Giữ LED TẮT.");
    forceTurnOffAllLeds();
    delay(1000);
  }
}

void loop() {
  // 1. Kiểm tra Nút bấm vật lý Reset
  if (isButtonPressed()) {
    delay(50);
    if (isButtonPressed()) {
      Serial.println("\n[BTN] NÚT VẬT LÝ ĐƯỢC NHẤN! TẮT LED & Reset...");
      forceTurnOffAllLeds();
      
      if (sendResetSignal()) {
        runScanProcess();
      }
      
      while (isButtonPressed()) { delay(10); }
      return;
    }
  }

  // 2. Đồng bộ trạng thái LED realtime với Web UI & Server khi rảnh
  bool serverLedState = false;
  bool isMusicPlaying = false;
  if (getLedAndMusicStatus(serverLedState, isMusicPlaying)) {
    if (serverLedState) {
      turnOnAllLeds();
    } else {
      forceTurnOffAllLeds();
    }
  }

  // 3. Kiểm tra Cảm biến chuyển động PIR
  int currentState = digitalRead(PIR_PIN);
  if (currentState == HIGH) {
    Serial.println("\n[PIR] Phát hiện người!");
    
    if (triggerRaspberryPi()) {
      runScanProcess();
    } else {
      delay(1500);
    }
  }
  
  delay(100);
}